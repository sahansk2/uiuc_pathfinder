// ==UserScript==
// @name         ScrapeAndDownloadInterests
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        https://ece.illinois.edu/academics/ugrad/subdisciplines/*
// @icon         https://www.google.com/s2/favicons?domain=illinois.edu
// @grant        none
// @require      https://cdnjs.cloudflare.com/ajax/libs/PapaParse/5.3.1/papaparse.min.js
// ==/UserScript==

(function() {
    let interest = document.querySelector('title').innerText.split('|')[0].trim().toUpperCase();
    let courses = document.querySelector('#content').innerText.matchAll(/(\w{2}|\w{3}|\w{4}) (\d{3})/g);
    let finalArr = new Array();
    for (let course of courses) {
        finalArr.push({ courseNum: course[2], courseDept: course[1], interest: interest });
    }
    let csv = Papa.unparse(finalArr);
    let blob = new Blob([csv], {type: "csv"});
    let url = URL.createObjectURL(blob);
    let a = document.createElement('a');
    a.href = url;
    a.download = interest + '.csv';
    document.getElementsByTagName('body')[0].appendChild(a);
    a.click();
})();